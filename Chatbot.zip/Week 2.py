knowledge = {

    "python":
    "Python is a high level programming language.",

    "ai":
    "AI stands for Artificial Intelligence.",

    "oop":
    "OOP means Object Oriented Programming.",

    "cpu":
    "CPU is called the brain of computer.",

    "ram":
    "RAM stores temporary data.",

    "machine learning":
    "Machine Learning allows computers to learn from data."
}

greetings = ["hello", "hi", "hey"]

history = []

print("===== SIMPLE CHATBOT =====")

while True:

    user = input("\nYou: ").lower()

    history.append("You: " + user)

    if user in greetings:
        reply = "Hello! How can I help you?"

    elif user == "help":
        reply = "You can ask me about python, AI, OOP, CPU, RAM."

    elif user == "how are you":
        reply = "I am fine. Thanks for asking."

    elif user.startswith("what is "):

        topic = user.replace("what is ", "")

        if topic in knowledge:
            reply = knowledge[topic]

        else:
            reply = "Sorry, I don't know about that topic."

    elif user == "bye":
        reply = "Goodbye!"
        print("Bot:", reply)
        history.append("Bot: " + reply)
        break

    else:
        reply = "I don't understand."

    print("Bot:", reply)

    history.append("Bot: " + reply)

print("\n===== CHAT HISTORY =====")

for chat in history:
    print(chat)